package Plugins::the_Duke::Plugin;

use strict;

our %functions = ();
